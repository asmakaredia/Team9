﻿//Author: Asma Karedia
//Date: 4/7/2020
//Assignment: Homework 4
//Description: This program provides users the option to search and view 
//             300 movies within a Azure database




using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Karedia_Asma_Hw4.DAL;
using Karedia_Asma_Hw4.Models;
using Karedia_Asma_Hw4.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;




// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Karedia_Asma_Hw4.Controllers
{

    public class HomeController : Controller
    {
        //Instance of AppDbContext
        private AppDbContext _db;
        public HomeController(AppDbContext context)
        {
            _db = context;
        }

        //Index controller allows searches to happened
        public IActionResult Index(string SearchString)
         {
            ViewBag.AllGenres = GetAllGenres();
            var query = from m in _db.Movies
                   select m;
             if (SearchString != null && SearchString != "")
             {
                query = query.Where(m => m.Description.Contains(SearchString) || m.Title.Contains(SearchString));
             }

             List<Movie> SelectedMovies = query.Include(m => m.Genre).ToList();

             ViewBag.AllMovieCount = _db.Movies.Count();
             ViewBag.SelectedMovieCount = SelectedMovies.Count();

             return View(SelectedMovies.OrderByDescending(m => m.VoteAverage));
         }

        //Details of movies
        public IActionResult Details(int? id)
        {
            if (id == null)//MovieID not specified
            {
                return View("Error", new String[] { "MovieID not specified - which movie do you want to view?" });
            }
            Movie movie = _db.Movies.Include(m => m.Genre).FirstOrDefault(m => m.MovieID == id);
            if (movie == null) //Movie does not exist in database
            {
                return View("Error", new String[] { "Movie not found in database" });

            }        //if code gets this far, all is well
            return View(movie);
        }

        //Action method - DetailedSearch 
        public IActionResult DetailedSearch()
        { 
            ViewBag.AllGenres = GetAllGenres();
            SearchViewModel svm = new SearchViewModel();
            svm.SelectedGenreID = 0;
            svm.SelectedType = SelectionType.GreaterThan;
            return View();
        }

        public ActionResult DisplaySearchResults(SearchViewModel svm)
        {
            //LINQ query 
            var query = from m in _db.Movies
                        select m;

            //Title
            if (svm.SelectedMovie != null && svm.SelectedMovie != "")
            {
                query = query.Where(m => m.Title.Contains(svm.SelectedMovie) || m.Title.Contains(svm.SelectedMovie)); //user wants to search by name
            }

            //Description
            if (svm.SelectedDescription != null && svm.SelectedDescription != "")
            {
                query = query.Where(m => m.Description.Contains(svm.SelectedDescription));
            }

            //Genre
            if (svm.SelectedGenreID != 0)
            {
                query = query.Where(m => m.Genre.GenreID == svm.SelectedGenreID);
            }

            //Ratings
            if (svm.SelectVoteAverage != null)
            {
                //Code of radio buttons
                if (svm.SelectedType == SelectionType.GreaterThan)
                {
                    query = query.Where(m => m.VoteAverage >= svm.SelectVoteAverage);
                }
                else //selection type is less than
                {
                    query = query.Where(m => m.VoteAverage <= svm.SelectVoteAverage);
                }
            }

            //LINQ limits query to movies to ReleaseDate chosen
            if (svm.SelectedReleaseDate != null)
            {
                query = query.Where(m => m.ReleaseDate >= svm.SelectedReleaseDate);
            }

            //List of moives
            List<Movie> SelectedMovies = query.Include(m => m.Genre).ToList();

            //Counts total 
            ViewBag.AllMovieCount = _db.Movies.Count();
            ViewBag.SelectedMovieCount = SelectedMovies.Count();

            return View("Index", SelectedMovies.OrderByDescending(m => m.VoteAverage));
        }

        public SelectList GetAllGenres()
        {
            List<Genre> AllGenres = _db.Genres.ToList();

            //Add a fake genre to allow user to select nothing
            Genre NoGenre = new Genre() { GenreID = 0, GenreName = "All Genres" };
            AllGenres.Add(NoGenre);

            //Turn this into a select list
            SelectList slAllGenres = new SelectList(AllGenres.OrderBy(g => g.GenreID), "GenreID", "GenreName");

            //return the select list you searched
            return slAllGenres;

        }


    }
}