﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Karedia_Asma_Hw4.Migrations
{
    public partial class SetupUpdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
