﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;

namespace Karedia_Asma_Hw4.Models
{
    public class AppUser : IdentityUser
    {
    }
}
