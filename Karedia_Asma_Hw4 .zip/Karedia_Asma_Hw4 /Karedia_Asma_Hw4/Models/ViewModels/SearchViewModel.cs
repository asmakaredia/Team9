﻿using Karedia_Asma_Hw4.Controllers;
using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace Karedia_Asma_Hw4.Models.ViewModels

{
        public enum SelectionType { GreaterThan, LessThan }
        public class SearchViewModel
        {
            [Display(Name = "Search Movie Title:")]
            public String SelectedMovie { get; set; }

            [Display(Name = "Search description:")]
            public String SelectedDescription { get; set; }

            [Display(Name = "Select a genre:")]
            public Int32 SelectedGenreID { get; set; }

            [Display(Name = "Rating:")]
            public Decimal? SelectVoteAverage { get; set; }

            public SelectionType SelectedType { get; set; }

            [Display(Name = "Released After:")]
            public DateTime? SelectedReleaseDate { get; set; }

        }
    
}
